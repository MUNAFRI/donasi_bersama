export default function Home() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen bg-gray-50">
      <h1 className="text-3xl font-bold mb-4">Situs Penggalangan Dana</h1>
      <p>Selamat datang di platform donasi dan kebaikan 💖</p>
    </main>
  );
}